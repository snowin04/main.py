from django.apps import AppConfig


class ToppageConfig(AppConfig):
    name = 'toppage'
